Exact one-open exotic JSON prototype and React DOM-spread negative candidate.
